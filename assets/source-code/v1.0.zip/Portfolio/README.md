# Rohit Portfolio

Static portfolio coded from scratch with pure html & css.
